{\rtf1\ansi\ansicpg1252\cocoartf2513
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fswiss\fcharset0 Helvetica-Bold;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 How to Run: \
\
1. Install IntelliJ IDEA\
2. Open the App\
3. Click Open Project\
4. Navigate to the project 
\f1\b Folder
\f0\b0 \
5. Click the green \'93Play\'94 triangle (green) button on the top right corner\
6. The game will run 10 times (MCT vs MCT with Heuristics)}